package com.cafe.serv;

import com.cafe.dto.Menu;

public interface MenuService {
	public Menu getItem(int itemId);
}
