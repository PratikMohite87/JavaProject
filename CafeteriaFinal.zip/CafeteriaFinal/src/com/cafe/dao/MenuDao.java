package com.cafe.dao;

import com.cafe.dto.Menu;

public interface MenuDao {
	public Menu getProduct(int itemId);
}
